<?php
$host = "localhost";  // XAMPP default host
$user = "root";       // XAMPP default username
$pass = "";           // No password for XAMPP
$db = "health_haven"; // Database name
$port = 4306;         // Change to 3307 if needed

// Create database connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $contact = trim($_POST['contact']);
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment']; // Match table column name
    $feedback = trim($_POST['feedback']);
    
     // Handle causes (multiple checkboxes)
     if (!empty($_POST['cause']) && is_array($_POST['cause'])) {
        $causes = implode(", ", $_POST['cause']); // Convert array to comma-separated string
    } else {
        $causes = "None"; // Default if no cause is selected
    }

    // Insert data into the donations table
    $sql = "INSERT INTO donations (name, contact, amount, payment_method, causes, feedback) 
            VALUES ('$name', '$contact', '$amount', '$payment_method', '$causes', '$feedback')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Donation Successful! Thank you for your support.'); window.location.href='donate.html';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation Status - HEALTH Haven</title>
    <link rel="stylesheet" href="donate_success.css">
</head>
<body>
    <div class="donation-status">
        <h2>Donation Status</h2>
        <?php echo $message; ?>
        <a href="donate.html" class="btn">Back to Donation Page</a>
    </div>
</body>
</html>
