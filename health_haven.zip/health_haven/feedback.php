<?php
$host = "localhost";  // XAMPP default host
$user = "root";       // XAMPP default username
$pass = "";           // No password for XAMPP
$db = "health_haven"; // Database name
$port = 4306;         // Change to 3307 if needed

// Create a database connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMessage = "";
$errorMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $rating = $_POST['rating'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO feedback (name, contact, rating) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $name, $contact, $rating);

    if ($stmt->execute()) {
        $successMessage = "Thank you for your feedback!";
    } else {
        $errorMessage = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Submission</title>
    <link rel="stylesheet" href="feedback.css">
    </head>

    <body>
    <?php if (!empty($successMessage)) { ?>
        <div class="message success"><?php echo $successMessage; ?></div>
    <?php } ?>
    
    <?php if (!empty($errorMessage)) { ?>
        <div class="message error"><?php echo $errorMessage; ?></div>
    <?php } ?>
    
    <br>
    <a href="home.html" class="back-button">Back to Feedback Form</a>
</body>
</html>
