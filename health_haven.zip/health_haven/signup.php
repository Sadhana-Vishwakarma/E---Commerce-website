<?php
$host = "localhost";  // XAMPP default host
$user = "root";       // XAMPP default username
$pass = "";           // No password for XAMPP
$db = "health_haven"; // Database name
$port = 4306; // Change to 3307 if needed

// Create connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = ""; // To store success or error messages

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Secure password

    // Check if email already exists
    $check_email = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($check_email);
    
    if ($result->num_rows > 0) {
        $message = "<p class='error'>❌ Email already exists! Please use a different email.</p>";
    } else {
        // Insert user data into table
        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
        if ($conn->query($sql) === TRUE) {
            $message = "<p class='success'>🎉 Signup successful! Welcome, <strong>" . $name . "</strong></p>";
        } else {
            $message = "<p class='error'>❌ Error: " . $sql . "<br>" . $conn->error . "</p>";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Result</title>
    <link rel="stylesheet" href="signup_success.css">
</head>
<body>
    <div class="signup-container">
        <div class="signup-box">
            <h2>Signup Status</h2>
            <?php echo $message; ?>
            <a href="login.html" class="btn">Go to Login</a>
            <a href="signup.html" class="btn back">Back to Signup</a>
        </div>
    </div>
</body>
</html>
