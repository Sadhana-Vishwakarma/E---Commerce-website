<?php
$host = "localhost";  // XAMPP default host
$user = "root";       // XAMPP default username
$pass = "";           // No password for XAMPP
$db = "health_haven"; // Database name
$port = 4306;         // Change to 3307 if needed

// Create a database connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$successMessage = "";
$errorMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $interest = $_POST['interest'];
    $message = $_POST['message'];

    // Check if email already exists
    $check_email = $conn->prepare("SELECT email FROM volunteers WHERE email = ?");
    $check_email->bind_param("s", $email);
    $check_email->execute();
    $check_email->store_result();

    if ($check_email->num_rows > 0) {
        $errorMessage = "This email is already registered!";
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO volunteers (name, email, phone, interest, message) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $phone, $interest, $message);

        if ($stmt->execute()) {
            header("Location: thank_you.php"); // Redirect to the thank you page
            exit();
        } else {
            $errorMessage = "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    $check_email->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Submission</title>
    <link rel="stylesheet" href="volunteer_success.css"> 

</head>
<body>
    <?php if (!empty($errorMessage)) { ?>
        <div class="message error"><?php echo $errorMessage; ?></div>
    <?php } ?>
    
    <br>
    <a href="home.html" class="back-button">Back to Volunteer Form</a>
</body>
</html>












?>