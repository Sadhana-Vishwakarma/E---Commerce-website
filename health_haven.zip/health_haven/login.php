<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "health_haven";
$port = 4306; // Change to 4306 if needed

// Create database connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = ""; // Variable to store login message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Check if user exists
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $message = "<p class='success'>🎉 Login successful! Welcome, <strong>" . $row['name'] . "</strong></p>";
        } else {
            $message = "<p class='error'>❌ Incorrect password!</p>";
        }
    } else {
        $message = "<p class='error'>❌ User not found!</p>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Result</title>
    <link rel="stylesheet" href="login_success.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Login Status</h2>
            <?php echo $message; ?>
            <a href="home.html" class="btn">Go to Dashboard</a>
            <a href="login.html" class="btn logout">Back to Login</a>
        </div>
    </div>
</body>
</html>
