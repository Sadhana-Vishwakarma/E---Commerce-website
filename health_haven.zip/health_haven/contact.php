<?php
$host = "localhost";  // XAMPP default host
$user = "root";       // XAMPP default username
$pass = "";           // No password for XAMPP
$db = "health_haven"; // Database name
$port = 4306;         // Change to 3307 if needed

// Create a database connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = ""; // Variable to store message status

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $msg = trim($_POST['message']);

    // SQL query to insert data into the contact table
    $sql = "INSERT INTO contact (name, email, phone, message) VALUES (?, ?, ?, ?)";

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $email, $phone, $msg);

    if ($stmt->execute()) {
        $message = "<p class='success'>✅ Message sent successfully! We will get back to you soon.</p>";
    } else {
        $message = "<p class='error'>❌ Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Status - HEALTH Haven</title>
    <link rel="stylesheet" href="contact.css">
</head>
<body>
    <div class="contact-container">
        <h2>Contact Status</h2>
        <?php echo $message; ?>
        <a href="contact.html" class="btn">Back to Contact Page</a>
    </div>
</body>
</html>
