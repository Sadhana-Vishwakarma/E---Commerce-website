<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You for Joining Us</title>
    <link rel="stylesheet" href="thank_you.css">
</head>
<body>

<div class="container">
    <h2>Thank You for Joining Us!</h2>
    <p>Your volunteer application has been received. We appreciate your willingness to help!</p>
    <a href="home.html" class="home-button">Go to Homepage</a>
</div>

</body>
</html>
